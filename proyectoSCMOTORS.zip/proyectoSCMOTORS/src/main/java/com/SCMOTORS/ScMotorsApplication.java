package com.SCMOTORS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScMotorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScMotorsApplication.class, args);
	}

}
